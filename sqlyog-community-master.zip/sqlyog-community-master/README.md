#SQLyog Community Edition
SQLyog is an all-round Management Tool (/'GUI'/'Frontend') for MySQL.
##[Download SQLyog Community Version](https://github.com/webyog/sqlyog-community/wiki/Downloads)

###Experience SQLyog power tools
SQLyog comes in 3 editions. Compare all our editions-[Learn more](https://www.webyog.com/product/sqlyogFeatureListExpanded/)

###SQLyog Trial
You can download a 14-day trial from-[Webyog download page](https://www.webyog.com/product/downloads/)

###SQLyog Professional, Enterprise, Ultimate Editions
Prices start from $69/user, with free updates (for major & minor versions) for one year.

[Price list for various editions of SQLyog](https://www.webyog.com/shop/)
