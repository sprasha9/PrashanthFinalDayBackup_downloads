#ifndef _INCLUDE_COMMUNITY_H_

#define _INCLUDE_COMMUNITY_H_

#include "resource.h"
#include "Symbols.h"

#endif