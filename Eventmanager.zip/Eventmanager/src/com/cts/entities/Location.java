package com.cts.entities;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Location {
private int locidationid;
private String locationname;

public int getLocidationid() {
	return locidationid;
}
public void setLocidationid(int locidationid) {
	this.locidationid = locidationid;
}
public String getLocationname() {
	return locationname;
}
public void setLocationname(String locationname) {
	this.locationname = locationname;
}


}
