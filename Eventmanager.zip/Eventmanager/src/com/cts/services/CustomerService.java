package com.cts.services;

import java.util.List;



import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.cts.dao.Customermanager;
import com.cts.entities.Customer;
import com.cts.entities.Message;
@Path("/customerservice")
public class CustomerService {
@POST
@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Path("/addcustomer")
	public Response AddCustomerservice(Customer customer){
		
boolean	status=Customermanager.AddCustomer(customer);
Message message=new Message();
message.setStatus("not insert");
if(status)
{
	message.setStatus("record added");
}

	return Response
							 .status(200)
				            .header("Access-Control-Allow-Origin", "*")
					            .header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
					            .header("Access-Control-Allow-Credentials", "true")
					            .header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
					            .header("Access-Control-Max-Age", "1209600")
					            .entity(message)
					            .build();
}

@GET
@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
@Path("/getcustomers")
public Response getCustomers()
{
	
	
	GenericEntity<List<Customer>> genentity=new GenericEntity<List<Customer>>(Customermanager.getAll()){};
	
	
	return Response
			 .status(200)
           .header("Access-Control-Allow-Origin", "*")
	            .header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
	            .header("Access-Control-Allow-Credentials", "true")
	            .header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
	            .header("Access-Control-Max-Age", "1209600")
	            .entity(genentity)
	            .build();

	
}

@Path("/getcustomerbyid/{customerid:\\d+}")
@GET
public Response getcustomerbyid(@PathParam("customerid")int customerid){
	Customer customer=Customermanager.getcustomerbyid(customerid);
	return Response
			 .status(200)
          .header("Access-Control-Allow-Origin", "*")
	            .header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
	            .header("Access-Control-Allow-Credentials", "true")
	            .header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
	            .header("Access-Control-Max-Age", "1209600")
	            .entity(customer)
	            .build();
}


}
